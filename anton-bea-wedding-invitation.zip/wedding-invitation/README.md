# Anton & Bea Wedding Invitation Website

Elegant minimalist-luxury invitation website with RSVP form that writes directly to a Google Sheet.

## Files
- `index.html` — Complete single-page website (open this file or host it)

## How to Connect the RSVP Form to Google Sheets

### Step 1: Create the Google Sheet
1. Go to [sheets.google.com](https://sheets.google.com) and create a new spreadsheet.
2. Name it something like **"Anton & Bea RSVPs"**.
3. In the first row, add these headers (exactly):

| A          | B     | C         | D      | E       | F         |
|------------|-------|-----------|--------|---------|-----------|
| Timestamp  | Name  | Email     | Attending | Guests | Message   |

### Step 2: Create the Apps Script
1. In your Google Sheet, go to **Extensions → Apps Script**.
2. Delete any existing code and paste the following:

```javascript
function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var data = JSON.parse(e.postData.contents);
    
    sheet.appendRow([
      data.timestamp || new Date().toLocaleString(),
      data.name || "",
      data.email || "",
      data.attending || "",
      data.guests || "",
      data.message || ""
    ]);
    
    return ContentService
      .createTextOutput(JSON.stringify({ status: "success" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: "error", message: error.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService
    .createTextOutput("Anton & Bea RSVP endpoint is working.")
    .setMimeType(ContentService.MimeType.TEXT);
}
```

3. Click the **Save** icon (or Ctrl/Cmd + S). Name the project “Wedding RSVP”.

### Step 3: Deploy as Web App
1. Click **Deploy → New deployment**.
2. Click the gear icon next to “Select type” and choose **Web app**.
3. Settings:
   - **Description**: RSVP Form
   - **Execute as**: Me
   - **Who has access**: Anyone
4. Click **Deploy**.
5. Authorize the app when prompted (you may need to click “Advanced” → “Go to … (unsafe)” because it’s your own script).
6. Copy the **Web app URL** (it looks like `https://script.google.com/macros/s/XXXXXXXX/exec`).

### Step 4: Connect the Website
1. Open `index.html` in a text editor.
2. Find this line near the bottom:

```js
const SCRIPT_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE";
```

3. Replace the placeholder with your Web app URL:

```js
const SCRIPT_URL = "https://script.google.com/macros/s/XXXXX/exec";
```

4. Save the file.

### Step 5: Test
- Open the website and submit a test RSVP.
- Check your Google Sheet — a new row should appear within a few seconds.

## Hosting the Website
You can host the single `index.html` file for free on:

- **Netlify Drop** (drag & drop the file)
- **GitHub Pages**
- **Vercel**
- **Cloudflare Pages**
- Or simply send the HTML file / zip to guests (they can open it offline, but the form needs internet).

## Design Notes
- Color palette: Cream / soft beige with muted gold accents
- Typography: Playfair Display + Cormorant Garamond + Montserrat
- Fully responsive
- Minimalist luxury aesthetic

## Optional Improvements
- Add a photo of the couple in the hero
- Change the RSVP deadline date in the HTML
- Add dress code or other details in the Details section
- Password-protect the page if desired

---

Made with care for Anton & Bea ✨
